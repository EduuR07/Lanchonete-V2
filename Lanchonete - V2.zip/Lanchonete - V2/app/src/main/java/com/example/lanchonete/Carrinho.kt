package com.example.lanchonete

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

data class ItemCarrinho(
    val produto: Produto,
    val quantidade: Int
)

const val TAXA_ENTREGA = 5.00

class EstadoCarrinho {

    val itens = mutableStateListOf<ItemCarrinho>()

    // Usado para mostrar a mensagem quando um produto é adicionado
    var ultimoProdutoAdicionado by mutableStateOf<String?>(null)
        private set

    // Cada vez que adicionamos algo, esse número muda.
    // Assim o Compose sabe que deve mostrar uma nova animação/mensagem.
    var eventoAdicao by mutableIntStateOf(0)
        private set

    val quantidadeTotal: Int
        get() = itens.sumOf { it.quantidade }

    val subtotal: Double
        get() = itens.sumOf {
            it.produto.preco * it.quantidade
        }

    val total: Double
        get() = if (itens.isEmpty()) {
            0.0
        } else {
            subtotal + TAXA_ENTREGA
        }

    fun adicionar(
        produto: Produto,
        quantidade: Int = 1
    ) {

        val indice = itens.indexOfFirst {
            it.produto.id == produto.id
        }

        if (indice == -1) {

            itens.add(
                ItemCarrinho(
                    produto = produto,
                    quantidade = quantidade
                )
            )

        } else {

            val item = itens[indice]

            itens[indice] = item.copy(
                quantidade = item.quantidade + quantidade
            )
        }

        // Dispara o feedback visual
        ultimoProdutoAdicionado = produto.nome
        eventoAdicao++
    }

    fun diminuir(produto: Produto) {

        val indice = itens.indexOfFirst {
            it.produto.id == produto.id
        }

        if (indice == -1) {
            return
        }

        val item = itens[indice]

        if (item.quantidade > 1) {

            itens[indice] = item.copy(
                quantidade = item.quantidade - 1
            )

        } else {

            itens.removeAt(indice)
        }
    }

    fun limpar() {
        itens.clear()
    }
}
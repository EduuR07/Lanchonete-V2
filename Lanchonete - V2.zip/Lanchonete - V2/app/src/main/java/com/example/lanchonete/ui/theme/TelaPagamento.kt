package com.example.lanchonete

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Money
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Pix
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class FormaPagamento(
    val nome: String,
    val descricao: String,
    val icone: ImageVector
)

@Composable
fun TelaPagamento(
    total: Double,
    endereco: String,
    aoVoltar: () -> Unit,
    aoConfirmar: (String) -> Unit
) {

    var pagamentoSelecionado by remember {
        mutableStateOf<String?>(null)
    }

    val formasPagamento = listOf(

        FormaPagamento(
            nome = "Pix",
            descricao = "Pagamento instantâneo",
            icone = Icons.Filled.Pix
        ),

        FormaPagamento(
            nome = "Cartão de crédito",
            descricao = "Pague com cartão na entrega",
            icone = Icons.Filled.CreditCard
        ),

        FormaPagamento(
            nome = "Cartão de débito",
            descricao = "Pague com cartão na entrega",
            icone = Icons.Filled.Payments
        ),

        FormaPagamento(
            nome = "Dinheiro",
            descricao = "Pagamento em dinheiro na entrega",
            icone = Icons.Filled.Money
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),

        verticalArrangement =
            Arrangement.spacedBy(16.dp)
    ) {

        /*
         * TOPO
         */
        Row(
            modifier =
                Modifier.fillMaxWidth(),

            verticalAlignment =
                Alignment.CenterVertically
        ) {

            IconButton(
                onClick = aoVoltar
            ) {

                Icon(
                    imageVector =
                        Icons.AutoMirrored.Filled.ArrowBack,

                    contentDescription =
                        "Voltar"
                )
            }

            Text(
                text =
                    "Forma de pagamento",

                fontSize = 20.sp,

                fontWeight =
                    FontWeight.Bold
            )
        }

        Text(
            text =
                "Como você deseja pagar?",

            fontSize = 18.sp,

            fontWeight =
                FontWeight.SemiBold
        )

        /*
         * FORMAS DE PAGAMENTO
         */
        formasPagamento.forEach { forma ->

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {

                        pagamentoSelecionado =
                            forma.nome
                    }
            ) {

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),

                    verticalAlignment =
                        Alignment.CenterVertically,

                    horizontalArrangement =
                        Arrangement.spacedBy(12.dp)
                ) {

                    Icon(
                        imageVector =
                            forma.icone,

                        contentDescription =
                            forma.nome,

                        tint =
                            MaterialTheme
                                .colorScheme
                                .primary
                    )

                    Column(
                        modifier =
                            Modifier.weight(1f)
                    ) {

                        Text(
                            text =
                                forma.nome,

                            fontSize = 16.sp,

                            fontWeight =
                                FontWeight.SemiBold
                        )

                        Text(
                            text =
                                forma.descricao,

                            fontSize = 13.sp,

                            color =
                                MaterialTheme
                                    .colorScheme
                                    .outline
                        )
                    }

                    RadioButton(

                        selected =
                            pagamentoSelecionado ==
                                    forma.nome,

                        onClick = {

                            pagamentoSelecionado =
                                forma.nome
                        }
                    )
                }
            }
        }

        HorizontalDivider()

        /*
         * ENDEREÇO
         */
        Text(
            text =
                "Endereço de entrega",

            fontSize = 15.sp,

            fontWeight =
                FontWeight.SemiBold
        )

        Text(
            text =
                endereco,

            fontSize = 14.sp,

            color =
                MaterialTheme
                    .colorScheme
                    .outline
        )

        HorizontalDivider()

        /*
         * TOTAL
         */
        Row(
            modifier =
                Modifier.fillMaxWidth(),

            horizontalArrangement =
                Arrangement.SpaceBetween
        ) {

            Text(
                text =
                    "Total",

                fontSize = 18.sp,

                fontWeight =
                    FontWeight.Bold
            )

            Text(
                text =
                    formatarPreco(total),

                fontSize = 18.sp,

                fontWeight =
                    FontWeight.Bold,

                color =
                    MaterialTheme
                        .colorScheme
                        .primary
            )
        }

        /*
         * CONFIRMAR
         */
        Button(
            onClick = {

                pagamentoSelecionado?.let {
                    aoConfirmar(it)
                }
            },

            enabled =
                pagamentoSelecionado != null,

            modifier =
                Modifier.fillMaxWidth()
        ) {

            Text(
                text =
                    "Confirmar pedido"
            )
        }
    }
}
package com.example.lanchonete

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.LunchDining
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.lanchonete.ui.theme.LanchoneteTheme

@Composable
fun TelaInicial(
    carrinho: EstadoCarrinho
) {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(
                rememberScrollState()
            )
            .padding(16.dp),

        verticalArrangement =
            Arrangement.spacedBy(24.dp)
    ) {

        Cabecalho(
            quantidade =
                carrinho.quantidadeTotal
        )

        Banner()

        SecaoCategorias()

        SecaoDestaques(
            aoAdicionar = { produto ->

                carrinho.adicionar(
                    produto
                )
            }
        )
    }
}

@Composable
private fun Cabecalho(
    quantidade: Int
) {

    Row(
        modifier =
            Modifier.fillMaxWidth(),

        horizontalArrangement =
            Arrangement.SpaceBetween,

        verticalAlignment =
            Alignment.CenterVertically
    ) {

        Icon(
            imageVector =
                Icons.Filled.Menu,

            contentDescription =
                "Menu"
        )

        Text(
            text = "Lanchonete",
            fontSize = 20.sp,
            fontWeight =
                FontWeight.Bold
        )

        Box {

            Icon(
                imageVector =
                    Icons.Filled.ShoppingCart,

                contentDescription =
                    "Carrinho"
            )

            if (quantidade > 0) {

                Box(
                    modifier = Modifier
                        .align(
                            Alignment.TopEnd
                        )
                        .size(16.dp)
                        .background(
                            MaterialTheme
                                .colorScheme
                                .primary,

                            CircleShape
                        ),

                    contentAlignment =
                        Alignment.Center
                ) {

                    Text(
                        text =
                            quantidade.toString(),

                        fontSize = 10.sp,

                        color =
                            MaterialTheme
                                .colorScheme
                                .onPrimary
                    )
                }
            }
        }
    }
}

@Composable
private fun Banner() {

    Card(
        modifier =
            Modifier.fillMaxWidth(),

        colors =
            CardDefaults.cardColors(
                containerColor =
                    MaterialTheme
                        .colorScheme
                        .primaryContainer
            )
    ) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),

            horizontalArrangement =
                Arrangement.SpaceBetween,

            verticalAlignment =
                Alignment.CenterVertically
        ) {

            Text(
                text =
                    "O melhor lanche,\npertinho de você",

                fontSize = 20.sp,

                fontWeight =
                    FontWeight.SemiBold,

                color =
                    MaterialTheme
                        .colorScheme
                        .onPrimaryContainer
            )

            Icon(
                imageVector =
                    Icons.Filled.LunchDining,

                contentDescription = null,

                modifier =
                    Modifier.size(56.dp),

                tint =
                    MaterialTheme
                        .colorScheme
                        .onPrimaryContainer
            )
        }
    }
}

@Composable
private fun SecaoCategorias() {

    Column(
        verticalArrangement =
            Arrangement.spacedBy(12.dp)
    ) {

        Text(
            text = "Categorias",
            fontSize = 16.sp,
            fontWeight =
                FontWeight.SemiBold
        )

        Row(
            horizontalArrangement =
                Arrangement.spacedBy(12.dp)
        ) {

            categorias.forEach { categoria ->

                Card(
                    modifier =
                        Modifier.weight(1f)
                ) {

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(
                                vertical = 14.dp
                            ),

                        horizontalAlignment =
                            Alignment.CenterHorizontally,

                        verticalArrangement =
                            Arrangement.spacedBy(6.dp)
                    ) {

                        Icon(
                            imageVector =
                                iconeDaCategoria(
                                    categoria
                                ),

                            contentDescription =
                                null,

                            modifier =
                                Modifier.size(26.dp)
                        )

                        Text(
                            text = categoria,

                            fontSize = 10.sp,

                            maxLines = 1,

                            overflow =
                                TextOverflow.Ellipsis,

                            textAlign =
                                TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SecaoDestaques(
    aoAdicionar: (Produto) -> Unit
) {

    Column(
        verticalArrangement =
            Arrangement.spacedBy(12.dp)
    ) {

        Row(
            modifier =
                Modifier.fillMaxWidth(),

            horizontalArrangement =
                Arrangement.SpaceBetween,

            verticalAlignment =
                Alignment.CenterVertically
        ) {

            Text(
                text = "Destaques",
                fontSize = 16.sp,
                fontWeight =
                    FontWeight.SemiBold
            )

            Text(
                text = "Ver todos",
                fontSize = 13.sp,
                color =
                    MaterialTheme
                        .colorScheme
                        .primary
            )
        }

        produtos
            .take(2)
            .forEach { produto ->

                CardDestaque(
                    produto = produto,

                    aoAdicionar = {
                        aoAdicionar(produto)
                    }
                )
            }
    }
}

@Composable
private fun CardDestaque(
    produto: Produto,
    aoAdicionar: () -> Unit
) {

    Card(
        modifier =
            Modifier.fillMaxWidth()
    ) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),

            verticalAlignment =
                Alignment.CenterVertically,

            horizontalArrangement =
                Arrangement.spacedBy(12.dp)
        ) {

            Icon(
                imageVector =
                    iconeDaCategoria(
                        produto.categoria
                    ),

                contentDescription = null,

                modifier =
                    Modifier.size(40.dp)
            )

            Column(
                modifier =
                    Modifier.weight(1f)
            ) {

                Text(
                    text = produto.nome,

                    fontSize = 15.sp,

                    fontWeight =
                        FontWeight.SemiBold
                )

                Text(
                    text =
                        formatarPreco(
                            produto.preco
                        ),

                    fontSize = 14.sp,

                    color =
                        MaterialTheme
                            .colorScheme
                            .primary
                )
            }

            IconButton(
                onClick =
                    aoAdicionar
            ) {

                Icon(
                    imageVector =
                        Icons.Filled.AddCircle,

                    contentDescription =
                        "Adicionar"
                )
            }
        }
    }
}

@Preview(
    showBackground = true
)
@Composable
private fun TelaInicialPreview() {

    LanchoneteTheme {

        TelaInicial(
            EstadoCarrinho()
        )
    }
}
package com.example.lanchonete

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun TelaEndereco(
    aoVoltar: () -> Unit,

    aoConfirmar: (
        rua: String,
        numero: String,
        complemento: String,
        bairro: String,
        cidade: String,
        cep: String
    ) -> Unit
) {

    var rua by remember {
        mutableStateOf("")
    }

    var numero by remember {
        mutableStateOf("")
    }

    var complemento by remember {
        mutableStateOf("")
    }

    var bairro by remember {
        mutableStateOf("")
    }

    var cidade by remember {
        mutableStateOf("")
    }

    var cep by remember {
        mutableStateOf("")
    }

    val formularioValido =
        rua.isNotBlank() &&
                numero.isNotBlank() &&
                bairro.isNotBlank() &&
                cidade.isNotBlank() &&
                cep.isNotBlank()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(
                rememberScrollState()
            )
            .padding(16.dp),

        verticalArrangement =
            Arrangement.spacedBy(14.dp)
    ) {

        Row(
            modifier =
                Modifier.fillMaxWidth(),

            verticalAlignment =
                Alignment.CenterVertically
        ) {

            IconButton(
                onClick = aoVoltar
            ) {

                Icon(
                    imageVector =
                        Icons.AutoMirrored.Filled.ArrowBack,

                    contentDescription =
                        "Voltar"
                )
            }

            Text(
                text =
                    "Endereço de entrega",

                fontSize = 20.sp,

                fontWeight =
                    FontWeight.Bold
            )
        }

        Icon(
            imageVector =
                Icons.Filled.Home,

            contentDescription = null,

            tint =
                MaterialTheme
                    .colorScheme
                    .primary
        )

        Text(
            text =
                "Informe onde deseja receber seu pedido.",

            fontSize = 16.sp
        )

        OutlinedTextField(
            value = cep,

            onValueChange = {
                cep = it
            },

            label = {
                Text("CEP")
            },

            placeholder = {
                Text("00000-000")
            },

            modifier =
                Modifier.fillMaxWidth(),

            singleLine = true
        )

        OutlinedTextField(
            value = rua,

            onValueChange = {
                rua = it
            },

            label = {
                Text("Rua")
            },

            modifier =
                Modifier.fillMaxWidth(),

            singleLine = true
        )

        Row(
            modifier =
                Modifier.fillMaxWidth(),

            horizontalArrangement =
                Arrangement.spacedBy(10.dp)
        ) {

            OutlinedTextField(
                value = numero,

                onValueChange = {
                    numero = it
                },

                label = {
                    Text("Número")
                },

                modifier =
                    Modifier.weight(1f),

                singleLine = true
            )

            OutlinedTextField(
                value = complemento,

                onValueChange = {
                    complemento = it
                },

                label = {
                    Text("Complemento")
                },

                modifier =
                    Modifier.weight(1.5f),

                singleLine = true
            )
        }

        OutlinedTextField(
            value = bairro,

            onValueChange = {
                bairro = it
            },

            label = {
                Text("Bairro")
            },

            modifier =
                Modifier.fillMaxWidth(),

            singleLine = true
        )

        OutlinedTextField(
            value = cidade,

            onValueChange = {
                cidade = it
            },

            label = {
                Text("Cidade")
            },

            modifier =
                Modifier.fillMaxWidth(),

            singleLine = true
        )

        Button(
            onClick = {

                aoConfirmar(
                    rua,
                    numero,
                    complemento,
                    bairro,
                    cidade,
                    cep
                )
            },

            enabled =
                formularioValido,

            modifier =
                Modifier.fillMaxWidth()
        ) {

            Text(
                text =
                    "Continuar para pagamento"
            )
        }
    }
}
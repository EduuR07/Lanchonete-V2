package com.example.lanchonete

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.lanchonete.ui.theme.LanchoneteTheme

@Composable
fun TelaCardapio(
    carrinho: EstadoCarrinho
) {

    var filtroSelecionado by remember {
        mutableStateOf("Todos")
    }

    var produtoSelecionado by remember {
        mutableStateOf<Produto?>(null)
    }

    /*
     * Se o usuário selecionou um produto,
     * mostra a tela de detalhes.
     */
    if (produtoSelecionado != null) {

        TelaDetalheProduto(
            produto = produtoSelecionado!!,
            carrinho = carrinho,
            aoVoltar = {
                produtoSelecionado = null
            }
        )

        return
    }

    val listaFiltrada =
        if (filtroSelecionado == "Todos") {

            produtos

        } else {

            produtos.filter {
                it.categoria == filtroSelecionado
            }
        }

    Column(
        modifier = Modifier.fillMaxSize()
    ) {

        BarraTopo()

        FiltrosCategoria(
            selecionado = filtroSelecionado,
            aoSelecionar = {
                filtroSelecionado = it
            }
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {

            items(
                items = listaFiltrada,
                key = {
                    it.id
                }
            ) { produto ->

                ItemCardapio(
                    produto = produto,

                    aoClicar = {
                        produtoSelecionado = produto
                    },

                    aoAdicionar = {
                        carrinho.adicionar(produto)
                    }
                )
            }
        }
    }
}

@Composable
private fun BarraTopo() {

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                horizontal = 16.dp,
                vertical = 8.dp
            ),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {

        IconButton(
            onClick = { }
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Voltar"
            )
        }

        Text(
            text = "Cardápio",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )

        IconButton(
            onClick = { }
        ) {
            Icon(
                imageVector = Icons.Filled.Search,
                contentDescription = "Buscar"
            )
        }
    }
}

@Composable
private fun FiltrosCategoria(
    selecionado: String,
    aoSelecionar: (String) -> Unit
) {

    val opcoes =
        listOf("Todos") + categorias

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(
                rememberScrollState()
            )
            .padding(
                horizontal = 16.dp
            ),
        horizontalArrangement =
            Arrangement.spacedBy(8.dp)
    ) {

        opcoes.forEach { opcao ->

            FilterChip(
                selected = selecionado == opcao,

                onClick = {
                    aoSelecionar(opcao)
                },

                label = {
                    Text(opcao)
                }
            )
        }
    }
}

@Composable
private fun ItemCardapio(
    produto: Produto,
    aoClicar: () -> Unit,
    aoAdicionar: () -> Unit
) {

    Card(
        onClick = aoClicar,
        modifier = Modifier.fillMaxWidth()
    ) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),

            verticalAlignment =
                Alignment.CenterVertically,

            horizontalArrangement =
                Arrangement.spacedBy(12.dp)
        ) {

            Icon(
                imageVector =
                    iconeDaCategoria(
                        produto.categoria
                    ),

                contentDescription = null,

                modifier =
                    Modifier.size(36.dp)
            )

            Column(
                modifier =
                    Modifier.weight(1f)
            ) {

                Text(
                    text = produto.nome,
                    fontSize = 15.sp,
                    fontWeight =
                        FontWeight.SemiBold
                )

                Text(
                    text =
                        formatarPreco(
                            produto.preco
                        ),

                    fontSize = 14.sp,

                    color =
                        MaterialTheme
                            .colorScheme
                            .primary
                )
            }

            IconButton(
                onClick = aoAdicionar
            ) {

                Icon(
                    imageVector =
                        Icons.Filled.AddCircle,

                    contentDescription =
                        "Adicionar ao carrinho"
                )
            }
        }
    }
}

@Preview(
    showBackground = true
)
@Composable
private fun TelaCardapioPreview() {

    LanchoneteTheme {

        TelaCardapio(
            EstadoCarrinho()
        )
    }
}
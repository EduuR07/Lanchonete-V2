package com.example.lanchonete

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.lanchonete.ui.theme.LanchoneteTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {

            LanchoneteTheme {

                AppLanchonete()
            }
        }
    }
}

data class ItemMenu(
    val rotulo: String,
    val icone: ImageVector
)

enum class EtapaCheckout {
    NENHUMA,
    ENDERECO,
    PAGAMENTO,
    CONFIRMACAO
}

val itensMenu = listOf(

    ItemMenu(
        "Início",
        Icons.Filled.Home
    ),

    ItemMenu(
        "Cardápio",
        Icons.Filled.RestaurantMenu
    ),

    ItemMenu(
        "Carrinho",
        Icons.Filled.ShoppingCart
    )
)

@Composable
fun AppLanchonete() {

    var abaSelecionada by remember {
        mutableIntStateOf(0)
    }

    var etapaCheckout by remember {
        mutableStateOf(EtapaCheckout.NENHUMA)
    }

    var enderecoSelecionado by remember {
        mutableStateOf("")
    }

    var formaPagamentoSelecionada by remember {
        mutableStateOf("")
    }

    var totalPedidoConfirmado by remember {
        mutableStateOf(0.0)
    }

    val carrinho = remember {
        EstadoCarrinho()
    }

    val snackbarHostState = remember {
        SnackbarHostState()
    }

    /*
     * Exibe mensagem quando um produto
     * é adicionado ao carrinho.
     */
    LaunchedEffect(carrinho.eventoAdicao) {

        if (carrinho.eventoAdicao > 0) {

            val nomeProduto =
                carrinho.ultimoProdutoAdicionado
                    ?: "Produto"

            snackbarHostState.showSnackbar(
                message = "$nomeProduto adicionado ao carrinho!"
            )
        }
    }

    Scaffold(

        snackbarHost = {

            SnackbarHost(
                hostState = snackbarHostState
            )
        },

        /*
         * A navbar aparece somente nas
         * telas principais do aplicativo.
         */
        bottomBar = {

            if (etapaCheckout == EtapaCheckout.NENHUMA) {

                NavigationBar {

                    itensMenu.forEachIndexed { indice, item ->

                        NavigationBarItem(

                            selected =
                                abaSelecionada == indice,

                            onClick = {

                                abaSelecionada =
                                    indice
                            },

                            icon = {

                                /*
                                 * Badge do carrinho.
                                 */
                                if (item.rotulo == "Carrinho") {

                                    BadgedBox(

                                        badge = {

                                            if (
                                                carrinho.quantidadeTotal > 0
                                            ) {

                                                Badge {

                                                    Text(
                                                        text =
                                                            carrinho
                                                                .quantidadeTotal
                                                                .toString()
                                                    )
                                                }
                                            }
                                        }

                                    ) {

                                        Icon(
                                            imageVector =
                                                item.icone,

                                            contentDescription =
                                                item.rotulo
                                        )
                                    }

                                } else {

                                    Icon(
                                        imageVector =
                                            item.icone,

                                        contentDescription =
                                            item.rotulo
                                    )
                                }
                            },

                            label = {

                                Text(
                                    text =
                                        item.rotulo
                                )
                            }
                        )
                    }
                }
            }
        }

    ) { espacamento ->

        Box(
            modifier =
                Modifier.padding(
                    espacamento
                )
        ) {

            when (etapaCheckout) {

                /*
                 * TELAS PRINCIPAIS
                 */
                EtapaCheckout.NENHUMA -> {

                    when (abaSelecionada) {

                        0 -> {

                            TelaInicial(
                                carrinho
                            )
                        }

                        1 -> {

                            TelaCardapio(
                                carrinho
                            )
                        }

                        else -> {

                            TelaCarrinho(

                                carrinho =
                                    carrinho,

                                aoFinalizarPedido = {

                                    etapaCheckout =
                                        EtapaCheckout.ENDERECO
                                }
                            )
                        }
                    }
                }

                /*
                 * ENDEREÇO
                 */
                EtapaCheckout.ENDERECO -> {

                    TelaEndereco(

                        aoVoltar = {

                            etapaCheckout =
                                EtapaCheckout.NENHUMA
                        },

                        aoConfirmar = {
                                rua,
                                numero,
                                complemento,
                                bairro,
                                cidade,
                                cep ->

                            enderecoSelecionado =

                                if (complemento.isBlank()) {

                                    "$rua, $numero - $bairro, $cidade - CEP $cep"

                                } else {

                                    "$rua, $numero - $complemento - $bairro, $cidade - CEP $cep"
                                }

                            etapaCheckout =
                                EtapaCheckout.PAGAMENTO
                        }
                    )
                }

                /*
                 * PAGAMENTO
                 */
                EtapaCheckout.PAGAMENTO -> {

                    TelaPagamento(

                        total =
                            carrinho.total,

                        endereco =
                            enderecoSelecionado,

                        aoVoltar = {

                            etapaCheckout =
                                EtapaCheckout.ENDERECO
                        },

                        aoConfirmar = { formaPagamento ->

                            /*
                             * Salvamos os dados antes
                             * de entrar na confirmação.
                             */
                            formaPagamentoSelecionada =
                                formaPagamento

                            totalPedidoConfirmado =
                                carrinho.total

                            etapaCheckout =
                                EtapaCheckout.CONFIRMACAO
                        }
                    )
                }

                /*
                 * CONFIRMAÇÃO
                 */
                EtapaCheckout.CONFIRMACAO -> {

                    TelaConfirmacaoPedido(

                        total =
                            totalPedidoConfirmado,

                        endereco =
                            enderecoSelecionado,

                        formaPagamento =
                            formaPagamentoSelecionada,

                        aoVoltarInicio = {

                            /*
                             * Pedido concluído.
                             * Limpa o carrinho.
                             */
                            carrinho.limpar()

                            /*
                             * Volta para a primeira aba.
                             */
                            abaSelecionada = 0

                            /*
                             * Encerra o checkout.
                             */
                            etapaCheckout =
                                EtapaCheckout.NENHUMA

                            /*
                             * Limpamos os dados temporários.
                             */
                            enderecoSelecionado = ""

                            formaPagamentoSelecionada = ""

                            totalPedidoConfirmado = 0.0
                        }
                    )
                }
            }
        }
    }
}